﻿#include "include.h"

// одеревенение после активации гена +
// сделать беком семен с передачей активного гена и возможность разным генам быть семенами +
// сделать смерть деревьям  от старости
// сделать мутации


const char gradient[] = "@EO T";

enum {
	semen = 0,
	green = 1,
	wood = 2,
	air = 3,
	ground = 4,
};

uint8_t r() {
	return rand() % 22;
}

uint8_t r0() {
	return rand() % 2;
}

class Tree {
public:
	int age = 0;
	int energy = 0;
	std::vector<std::vector<uint8_t>> genom = { // что отрастить в стороны + тип клетки
	{r(),r(),r(),r(),semen,},
	{r(),r(),r(),r(),r0(),},
	{r(),r(),r(),r(),r0(),},
	{r(),r(),r(),r(),r0(),},
	{r(),r(),r(),r(),r0(),},
	{r(),r(),r(),r(),r0(),},
	{r(),r(),r(),r(),r0(),},
	{r(),r(),r(),r(),r0(),},
	{r(),r(),r(),r(),r0(),},
	{r(),r(),r(),r(),r0(),},
	};
	int size_genom = genom.size();

};


class Cell {
public:
	uint8_t type;
	uint8_t gen_index;
	int index_tree;

	Cell(int t) {
		if (t == ground)
			become_ground();
		else
			become_air();
	}


	void become_live(int t, int i_t, int g = 0) {
		type = t;
		index_tree = i_t;
		gen_index = g;
	}

	void become(int t) {
		type = t;
	}

	void become_air() {
		type = air;
	}

	void become_ground() {
		type = ground;
	}

	void become_wood() {
		type = wood;
	}

};






class CellularAutomation {
public:
	std::vector<Tree> trees;
	std::vector<int> index_leave_arr;
	int max_age = 1000;
	int width;
	int height, extended_height;
	int length;
	std::vector<Cell> world_map;
	int frame_count = 0;
	enum { up, right, down, left };
	std::vector<int> directions;

	CellularAutomation(int w, int h) {
		width = w;
		height = h, extended_height = h + 1;
		length = w * h;
		world_map.resize(width * extended_height, Cell(air));
	
		for (int ind = 0; ind < world_map.size(); ind++) {

			int x = (ind % width);
			int y = (ind / width);

			if (y < 1 || y >= height)
				world_map[ind] = Cell(ground);

		}

		directions = { width , 1, -width, -1 };
	}

	void spawn(int x, int y) {
		try_spawn_semen(x + y * width);
	}

	int get_world_cell_type(int x, int y) {
		return world_map[x + y * width].type;
	}

	void step() {

		// записываем длину массива индексов живых клеток, чтобы пройтись только по тем что уже добавлены в массив, и не проходится по тем что будут добавлены внутри цикла
		int length_index_leave_arr = index_leave_arr.size();

		for (int ind = 0; ind < length_index_leave_arr; ind++) {
			// получаем индекс клетки
			int index = index_leave_arr[ind];
			// получаем клетку (я хуй знает стоит ли так делать, может сразу  обращаться по индексу к элементу или сделать ссылку на объект а не копиию)
			auto& c = world_map[index];
			// если эта клетка является семечком
			if (c.type == semen) {
				// получить индекс клетки снизу (будем проверять на возможность падения вниз)
				int index_d = index + directions[down];
				// возможно свич кейс не самая лучшая идея и стоит его заменить на иф элсе чтобы иметь возможность создавать внутри переменные
				switch (world_map[index_d].type) {
				case air:
					// пометить этот индекс как подлежащий удалению
					index_leave_arr[ind] = -index_leave_arr[ind];
					// добавить индекс клетки ниже в список живых
					index_leave_arr.push_back(index_d);
					// копировать данные в клетку ниже
					world_map[index_d].become_live(semen, c.index_tree, c.gen_index);
					break;
				case ground:
					c.become(green);
					break;
					
				default:
					// видимо снизу что-то твердое и неподходящее для того чтобы прорасти
					index_leave_arr[ind] = -index_leave_arr[ind];
				}
			}
			// если наша клетка является зеленью
			else if (c.type == green) {
				// пытаемся растить в 4 направлениях
				try_grow(c.index_tree, index, c.gen_index, ind);
			}
		}

		// убрать умершие клетки из списка живых
		index_leave_arr.erase(std::remove_if(index_leave_arr.begin(), index_leave_arr.end(),
			// если клетка не живая, в ней будет отрицательный индекс, равный положительному эквиваленту
			[&](const auto& a) { if (a < 0) { world_map[-a].become_air(); return true; } return false; }
		), index_leave_arr.end());


		frame_count++;
	}

private:

	void try_spawn_semen(int ind) {
		if (world_map[ind].type != air)
			return;
		spawn(semen, ind, trees.size());
	}



	void spawn(int type, int ind, int ind_tree, int ind_gen = 0) {
		index_leave_arr.push_back(ind);
		world_map[ind].become_live(type, 0, ind_gen);
		if (type == semen && trees.size()<1)
			trees.push_back(Tree());
	}

	void try_grow(int index_tree, int index, int gen_index, int ind1) {
		

		int aaaa = 1;
		auto& tree = trees[index_tree];
		auto& gen = tree.genom[gen_index];
		for (int i = 0; i < 4; i++) {
			// если наш ген ссылается на существующие гены
			
			if (gen[i] < tree.size_genom) {
				int index_n = index + directions[i];
				if (world_map[index_n].type == air) {
					int type_n = tree.genom[gen[i]][4];
					if (type_n == green) 
						spawn(type_n, index_n, index_tree, gen[i]);
					else if (type_n == semen) 
						spawn(type_n, index_n, trees.size(), gen[i]);
				}
			}
		}
		world_map[index].become_wood();
		//int test = index_leave_arr[ind];

		index_leave_arr[ind1] = -index_leave_arr[ind1];
	}


};



int main()
{

	

	
	
	
	CellularAutomation a(120, 30);
	a.spawn(40, 10);
	
	std::vector<char> str(a.length + 1 , ' ');


	str[a.length] = '\0';
	
	while (true) {

		a.step();
		for (int x = 0; x < 120; x++)
			for (int y = 0; y < 30; y++) {
				str[x + y * 120] = gradient[a.get_world_cell_type(x, 29 - y)];
			}
		//for (int ind = 0; ind < a.length; ind++)
		//	str[ind] = gradient[a.world_map[ind].type];
	
		std::cout << &str[0];
		//Sleep(250);
	}



}