#pragma once

#include <Windows.h> 
#include <iostream> 
#include <algorithm>
#include <vector>
#include <string>